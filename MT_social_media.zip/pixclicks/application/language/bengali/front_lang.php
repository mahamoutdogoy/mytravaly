<?php
$lang=array
(
	
);