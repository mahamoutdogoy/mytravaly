<?php 


$lang = array(
	'Account Import Facebook' => 'অ্যাকাউন্ট আমদানি ফেসবুক',
	'Clickable Image Campaign' => 'ক্লিকযোগ্য চিত্র প্রচারণা',
	'Clickable Image Campaign Scheduling' => 'ক্লিকযোগ্য চিত্র অভিযাত্রা নির্ধারণ',
	'Clickable Image Social Post' => 'ক্লিকযোগ্য চিত্র সামাজিক পোস্ট',
	'Custom Domain' => 'কাস্টম ডোমেন',
	'Traffic Analytics' => 'ট্রাফিক বিশ্লেষণ',
	'Overview' => 'ওভারভিউ',
	'Country Wise Report' => 'কান্ট্রি ওয়াইজ রিপোর্ট',
	'Browser Report' => 'ব্রাউজার রিপোর্ট',
	'OS Report' => 'ওএস রিপোর্ট',
	'Device Report' => 'ডিভাইস রিপোর্ট',
	'Raw Data' => 'কাঁচা ডেটা',
	'Raw Data Report' => 'কাঁচা ডেটা প্রতিবেদন',
	'Link Title' => 'লিঙ্ক শিরোনাম',
	'Link Description' => 'লিংক বর্ণনা',
	'Generate Your' => 'আপনার উত্পন্ন করুন',
	'Re-generate Your' => 'আপনার পুনরায় জেনারেট করুন',
	'Get Your' => 'আপনার পান',
	'Your' => 'আপনার'
);