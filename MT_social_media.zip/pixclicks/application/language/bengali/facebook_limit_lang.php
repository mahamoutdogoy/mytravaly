<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "ফেসবুক পরিষেবার শর্তাবলী লঙ্ঘন যে কিছু পোস্ট করবেন না দয়া করে। এটি খুব স্প্যাম হিসাবে বিবেচনা করা হয় যে খুব পোস্ট না।",
  "We recommend to use your own domain for your own branding and also for your security." => "আমরা আপনার নিজস্ব ব্র্যান্ডিং এবং আপনার নিরাপত্তা জন্য আপনার নিজস্ব ডোমেইন ব্যবহার করার সুপারিশ।",
  "We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone." => "আমরা যদি আপনার নিয়মগুলি লঙ্ঘন করে এমন কিছু খুঁজে পাই তাহলে আমরা আপনার অ্যাকাউন্ট অক্ষম করার অধিকার সংরক্ষণ করি। আমরা এই সিস্টেমটি সবার জন্য নিরাপদ রাখতে আপনার সহায়তার প্রশংসা করি।",
  'We recommend to use your own domain for your own branding and also for your security.' => 'আমরা আপনার নিজস্ব ব্র্যান্ডিং এবং আপনার নিরাপত্তা জন্য আপনার নিজস্ব ডোমেইন ব্যবহার করার সুপারিশ।',
  'use your own domain for post unlimited on Facebook.' => 'ফেসবুকে পোস্ট অসীম জন্য আপনার নিজের ডোমেইন ব্যবহার',
  'maximum allowed Facebook post per campaign using default action controller:' => 'ডিফল্ট অ্যাকশন নিয়ামক ব্যবহার করে সর্বাধিক প্রচারিত ফেসবুক পোস্ট অনুমোদিত:',
);