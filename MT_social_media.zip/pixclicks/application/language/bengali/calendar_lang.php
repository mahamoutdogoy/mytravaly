<?php

$lang['cal_su']			= "রবি";
$lang['cal_mo']			= "সোম";
$lang['cal_tu']			= "মঙ্গল";
$lang['cal_we']			= "বুধ";
$lang['cal_th']			= "বৃহঃ";
$lang['cal_fr']			= "শুক্র";
$lang['cal_sa']			= "শনি";
$lang['cal_sun']		= "রবি";
$lang['cal_mon']		= "সোম";
$lang['cal_tue']		= "মঙ্গল";
$lang['cal_wed']		= "বুধ";
$lang['cal_thu']		= "বৃহঃ";
$lang['cal_fri']		= "শুক্ব";
$lang['cal_sat']		= "শনি";
$lang['cal_sunday']		= "রবিবার";
$lang['cal_monday']		= "সোমবার";
$lang['cal_tuesday']	= "মঙ্গলবার";
$lang['cal_wednesday']	= "বুধবার";
$lang['cal_thursday']	= "বৃহঃবার";
$lang['cal_friday']		= "শুক্বারর";
$lang['cal_saturday']	= "শনিবার";
$lang['cal_jan']		= "জানুয়ারী";
$lang['cal_feb']		= "ফেব্রুয়ারী";
$lang['cal_mar']		= "মার্চ";
$lang['cal_apr']		= "এপ্রিল";
$lang['cal_may']		= "মে";
$lang['cal_jun']		= "জুন";
$lang['cal_jul']		= "জুলাই";
$lang['cal_aug']		= "আগস্ট";
$lang['cal_sep']		= "সেপ্টেম্বর";
$lang['cal_oct']		= "অক্টোবর";
$lang['cal_nov']		= "নভেম্বর";
$lang['cal_dec']		= "ডিসেম্বর";
$lang['cal_january']	= "জানুয়ারী";
$lang['cal_february']	= "ফেব্রুয়ারী";
$lang['cal_march']		= "মার্চ";
$lang['cal_april']		= "এপ্রিল";
$lang['cal_mayl']		= "মে";
$lang['cal_june']		= "জুন";
$lang['cal_july']		= "জুলাই";
$lang['cal_august']		= "আগস্ট";
$lang['cal_september']	= "সেপ্টেম্বর";
$lang['cal_october']	= "অক্টোবর";
$lang['cal_november']	= "নভেম্বর";
$lang['cal_december']	= "ডিসেম্বর";


/* End of file calendar_lang.php */
/* Location: ./system/language/english/calendar_lang.php */