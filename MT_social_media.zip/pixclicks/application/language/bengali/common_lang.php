<?php
$lang['Recent Activities'] = "সাম্প্রতিক কার্যক্রম";
$lang["Today's New Visitor Report"] = "আজকের নতুন ভিজিটর প্রতিবেদন";
// admin sidebar
$lang["save"] 			    = "সংরক্ষণ";
$lang["generate widget code"] 	= "Widget কোড তৈরী করুন";
$lang["send"] 			    = "পাঠান";
$lang["cancel"] 			= "বাতিল";
$lang["close"] 				= "বন্ধ";
$lang["add"] 				= "যোগ";
$lang["edit"] 				= "সম্পাদন";
$lang["update"] 			= "সম্পাদন";
$lang["details"] 			= "বিস্তারিত";
$lang["view"] 			    = "বিস্তারিত";
$lang["read"] 			    = "পড়ুন";
$lang["delete"] 			= "ডিলিট";
$lang["search"] 			= "অনুসন্ধান";
$lang["print"] 				= "প্রিন্ট";
$lang["download"] 			= "ডাউনলোড";
$lang["keyword"] 			= "কিওয়ার্ড";
$lang["actions"] 			= "ক্রিয়া সমূহ";
$lang["search by"] 			= "খুঁজুন";
$lang["total"] 			    = "মোট";
$lang["more info"] 			= "বিস্তারিত";

$lang["status"] 			= "অবস্থা";
$lang["active"] 			= "সক্রিয়";
$lang["inactive"] 			= "নিস্ক্রিয়";
$lang["yes"] 				= "হ্যাঁ";
$lang["no"] 				= "না";
$lang["OR"] 				= "অথবা";
$lang["only me"] 			= "শুধুমাত্র আমি";
$lang["everyone"] 			= "সকলে";
