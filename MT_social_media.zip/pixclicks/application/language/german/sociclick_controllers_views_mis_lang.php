<?php 


$lang = array (
  'Account Import Facebook' => 'Kontoimport Facebook',
  'Clickable Image Campaign' => 'Klickbare Imagekampagne',
  'Clickable Image Campaign Scheduling' => 'Anklickbare Bildkampagnenplanung',
  'Clickable Image Social Post' => 'Klickbarer Bild-Social Post',
  'Custom Domain' => 'Benutzerdefinierte Domäne',
  'Traffic Analytics' => 'Traffic Analytics',
  'Overview' => 'Überblick',
  'Country Wise Report' => 'Länderbericht',
  'Browser Report' => 'Browserbericht',
  'OS Report' => 'OS-Bericht',
  'Device Report' => 'Gerätebericht',
  'Raw Data' => 'Rohdaten',
  'Raw Data Report' => 'Rohdatenbericht',
  'Link Title' => 'Link Titel',
  'Link Description' => 'Link Beschreibung',
  'Generate Your' => 'Generieren Sie',
  'Re-generate Your' => 'Re-Generieren Sie Ihre',
  'Get Your' => 'Holen Sie sich',
  'Your' => 'Ihre',
);