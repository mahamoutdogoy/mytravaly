<?php
$lang['Recent Activities'] = "Kürzliche Aktivitäten";
$lang["Today's New Visitor Report"] = "Heute Neue Besucherbericht";
// admin sidebar
$lang["save"] 			    = "sparen";
$lang["generate widget code"] 	= "erzeugen Widget-Code";
$lang["send"] 			    = "senden";
$lang["cancel"] 			= "stornieren";
$lang["close"] 				= "schließen";
$lang["add"] 				= "hinzufügen";
$lang["edit"] 				= "bearbeiten";
$lang["update"] 			= "aktualisieren";
$lang["details"] 			= "Details";
$lang["view"] 			    = "Aussicht";
$lang["read"] 			    = "lesen";
$lang["delete"] 			= "löschen";
$lang["search"] 			= "Suche";
$lang["print"] 				= "drucken";
$lang["download"] 			= "herunterladen";
$lang["keyword"] 			= "Stichwort";
$lang["actions"] 			= "Aktionen";
$lang["search by"] 			= "Suche nach";
$lang["total"] 			    = "gesamt";
$lang["more info"] 			= "mehr Informationen";

$lang["status"] 			= "Status";
$lang["active"] 			= "aktiv";
$lang["inactive"] 			= "inaktiv";
$lang["yes"] 				= "ja";
$lang["no"] 				= "Nein";
$lang["OR"] 				= "ODER";
$lang["only me"] 			= "nur ich";
$lang["everyone"] 			= "jeder";




