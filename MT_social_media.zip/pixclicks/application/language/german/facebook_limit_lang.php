<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Bitte posten Sie nichts, was gegen die Nutzungsbedingungen von Facebook verstößt. Veröffentlichen Sie auch nicht zu viel, dass es als Spam betrachtet wird.",
  "We recommend to use your own domain for your own branding and also for your security." => "Wir empfehlen, Ihre eigene Domain für Ihr eigenes Branding und auch für Ihre Sicherheit zu nutzen.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Wir behalten uns das Recht vor, Ihr Konto zu deaktivieren, wenn wir feststellen, dass Sie gegen die Regeln verstoßen. Wir bedanken uns für Ihre Hilfe, damit dieses System für alle sicher ist.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'Wir empfehlen, Ihre eigene Domain für Ihr eigenes Branding und auch für Ihre Sicherheit zu nutzen.',
  'use your own domain for post unlimited on Facebook.' => 'verwenden Sie Ihre eigene Domain für Post-Unlimited auf Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'maximal erlaubter Facebook-Beitrag pro Kampagne mit Standard-Action-Controller:',
);