<?php 


$lang = array (
  'Account Import Facebook' => 'Importer un compte Facebook',
  'Clickable Image Campaign' => 'Campagne d`images cliquables',
  'Clickable Image Campaign Scheduling' => 'Planification de campagnes d`images cliquables',
  'Clickable Image Social Post' => 'Image cliquable',
  'Custom Domain' => 'Domaine personnalisé',
  'Traffic Analytics' => 'Analyse du trafic',
  'Overview' => 'Aperçu',
  'Country Wise Report' => 'Rapport Country Wise',
  'Browser Report' => 'Rapport du navigateur',
  'OS Report' => 'Rapport d`OS',
  'Device Report' => 'Rapport de l`appareil',
  'Raw Data' => 'Données brutes',
  'Raw Data Report' => 'Rapport de données brutes',
  'Link Title' => 'Titre du lien',
  'Link Description' => 'Description du lien',
  'Generate Your' => 'Générez votre',
  'Re-generate Your' => 'Re-générer votre',
  'Get Your' => 'Obtenez votre',
  'Your' => 'Votre',
);