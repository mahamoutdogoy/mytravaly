<?php
$lang['Recent Activities'] = "Activités récentes";
$lang["Today's New Visitor Report"] = "Nouveau rapport des visiteurs d'aujourd'hui";
// admin sidebar
$lang["save"] 			    = "enregistrer";
$lang["generate widget code"] 	= "générer du code widget de";
$lang["send"] 			    = "envoyer";
$lang["cancel"] 			= "Annuler";
$lang["close"] 				= "Fermer";
$lang["add"] 				= "ajouter";
$lang["edit"] 				= "modifier";
$lang["update"] 			= "mettre à jour";
$lang["details"] 			= "détails";
$lang["view"] 			    = "vue";
$lang["read"] 			    = "lire";
$lang["delete"] 			= "effacer";
$lang["search"] 			= "chercher";
$lang["print"] 				= "impression";
$lang["download"] 			= "Télécharger";
$lang["keyword"] 			= "mot-clé";
$lang["actions"] 			= "actes";
$lang["search by"] 			= "recherché par";
$lang["total"] 			    = "total";
$lang["more info"] 			= "Plus d'informations";

$lang["status"] 			= "statut";
$lang["active"] 			= "actif";
$lang["inactive"] 			= "inactif";
$lang["yes"] 				= "Oui";
$lang["no"] 				= "non";
$lang["OR"] 				= "OU";
$lang["only me"] 			= "seulement moi";
$lang["everyone"] 			= "tout le monde";

