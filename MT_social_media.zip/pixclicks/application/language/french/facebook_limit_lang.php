<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "S`il vous plaît ne publiez rien qui viole les conditions d`utilisation de Facebook. Aussi ne publiez pas trop que c`est considéré comme spam.",
  "We recommend to use your own domain for your own branding and also for your security." => "Nous vous recommandons d`utiliser votre propre domaine pour votre propre marque et pour votre sécurité.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Nous nous réservons le droit de désactiver votre compte si nous constatons que vous enfreignez les règles. Nous apprécions votre aide pour garder ce système sécuritaire pour tout le monde.',
  'We recommend to use your own domain for your own branding and also for your security.' => "Nous vous recommandons d`utiliser votre propre domaine pour votre propre marque et pour votre sécurité.",
  'use your own domain for post unlimited on Facebook.' => 'utiliser votre propre domaine pour post illimité sur Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => "maximum de messages Facebook autorisés par campagne à l`aide du contrôleur d'action par défaut:",
);