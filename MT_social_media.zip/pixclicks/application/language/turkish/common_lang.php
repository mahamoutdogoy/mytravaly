<?php

$lang = 

array (
  'Recent Activities' => 'Son İşlemler',
  "Today's New Visitor Report" => "Günlük Ziyaretci Raporu",
  'save' => 'Sakla',
  'generate widget code' => 'Widget Kodu Oluştur',
  'send' => 'Gönder',
  'cancel' => 'İptal Et',
  'close' => 'Bitir',
  'add' => 'Ekle',
  'edit' => 'Düzenle',
  'update' => 'Güncelle',
  'details' => 'Detaylar',
  'view' => 'Görüntüle',
  'read' => 'Oku',
  'delete' => 'Sil',
  'search' => 'Ara',
  'print' => 'Print',
  'download' => 'İndir',
  'keyword' => 'Anahtar Kelime',
  'actions' => 'İşlemler',
  'search by' => 'Ara',
  'total' => 'Total',
  'more info' => 'Detaylar',
  'status' => 'Durum',
  'active' => 'Aktif',
  'inactive' => 'Etkisiz',
  'yes' => 'Evet',
  'no' => 'Hayır',
  'OR' => 'YADA',
  'only me' => 'Sadece Ben',
  'everyone' => 'Herkes'
);