<?php 

$lang = array (
  'Account Import Facebook' => 'Hesap İçe Aktar Facebook',
  'Clickable Image Campaign' => 'Tıklanabilir Resim Kampanyası',
  'Clickable Image Campaign Scheduling' => 'Tıklanabilir Resim Kampanyası Planlaması',
  'Clickable Image Social Post' => 'Tıklanabilir Resim Social Post',
  'Custom Domain' => 'Özel Alan Adı',
  'Traffic Analytics' => 'Trafik Analizi',
  'Overview' => 'genel bakış',
  'Country Wise Report' => 'Ülke Bilge Raporu',
  'Browser Report' => 'Tarayıcı Raporu',
  'OS Report' => 'OS Raporu',
  'Device Report' => 'Cihaz Raporu',
  'Raw Data' => 'Ham Veri',
  'Raw Data Report' => 'Ham Veri Raporu',
  'Link Title' => 'Bağlantı Başlığı',
  'Link Description' => 'Bağlantı Açıklama',
  'Generate Your' => 'Senin üret',
  'Re-generate Your' => 'Senin yeniden üret',
  'Get Your' => 'Alın',
  'Your' => 'senin',
);