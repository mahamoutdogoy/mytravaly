<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Lütfen Facebook Hizmet Şartlarını ihlal eden herhangi bir şey göndermeyin. Ayrıca spam olarak kabul edilen çok fazla mesaj göndermeyin.",
  "We recommend to use your own domain for your own branding and also for your security." => "Kendi markanızı ve güvenliğiniz için kendi etki alanınızı kullanmanızı öneririz.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Kuralları ihlal ettiğiniz bir şey bulursak, hesabınızı devre dışı bırakma hakkımızı saklı tutuyoruz. Bu sistemi herkes için güvenli tutmak için yardımınız için teşekkür ederiz.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'Kendi markanızı ve güvenliğiniz için kendi etki alanınızı kullanmanızı öneririz.',
  'use your own domain for post unlimited on Facebook.' => "Facebook`ta sınırsız yayın yapmak için kendi alanınızı kullanın.",
  'maximum allowed Facebook post per campaign using default action controller:' => 'Varsayılan eylem denetleyicisini kullanarak kampanya başına izin verilen maksimum Facebook postası:',
);