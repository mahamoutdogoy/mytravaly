<?php
$lang['Recent Activities'] = "Actividades recientes";
$lang["Today's New Visitor Report"] = "Nuevo informe de Visitantes de hoy";
// admin sidebar
$lang["save"] 			    = "salvar";
$lang["generate widget code"] 	= "generar código del widget";
$lang["send"] 			    = "enviar";
$lang["cancel"] 			= "cancelar";
$lang["close"] 				= "cerca";
$lang["add"] 				= "añadir";
$lang["edit"] 				= "editar";
$lang["update"] 			= "actualizar";
$lang["details"] 			= "detalles";
$lang["view"] 			    = "ver";
$lang["read"] 			    = "leer";
$lang["delete"] 			= "borrar";
$lang["search"] 			= "buscar";
$lang["print"] 				= "impresión";
$lang["download"] 			= "descargar";
$lang["keyword"] 			= "palabra clave";
$lang["actions"] 			= "comportamiento";
$lang["search by"] 			= "busqueda";
$lang["total"] 			    = "total";
$lang["more info"] 			= "más información";

$lang["status"] 			= "estado";
$lang["active"] 			= "activo";
$lang["inactive"] 			= "inactivo";
$lang["yes"] 				= "sí";
$lang["no"] 				= "no";
$lang["OR"] 				= "O";
$lang["only me"] 			= "solo yo";
$lang["everyone"] 			= "todo el mundo";
