<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "No publique nada que viole los Términos de servicio de Facebook. Tampoco publiques demasiado que se considera spam.",
  "We recommend to use your own domain for your own branding and also for your security." => "Recomendamos utilizar su propio dominio para su propia marca y también para su seguridad.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Nos reservamos el derecho de inhabilitar su cuenta si encontramos algo que está violando las reglas. Apreciamos su ayuda para mantener este sistema seguro para todos.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'Recomendamos utilizar su propio dominio para su propia marca y también para su seguridad.',
  'use your own domain for post unlimited on Facebook.' => 'utiliza tu propio dominio para publicar ilimitadas en Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'publicación permitida máxima de Facebook por campaña usando el controlador de acción predeterminado:',
);