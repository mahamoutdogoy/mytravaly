<?php 

$lang = array (
  'Account Import Facebook' => 'Cuenta Importar Facebook',
  'Clickable Image Campaign' => 'Campaña de imagen con clic',
  'Clickable Image Campaign Scheduling' => 'Programación de campañas de imágenes con clics',
  'Clickable Image Social Post' => 'Publicación Social con Imagen Clicable',
  'Custom Domain' => 'Dominio personalizado',
  'Traffic Analytics' => 'Análisis de tráfico',
  'Overview' => 'Descripción general',
  'Country Wise Report' => 'Informe del país sabio',
  'Browser Report' => 'Informe del navegador',
  'OS Report' => 'Informe del sistema operativo',
  'Device Report' => 'Informe del dispositivo',
  'Raw Data' => 'Datos brutos',
  'Raw Data Report' => 'Informe de datos brutos',
  'Link Title' => 'Título del enlace',
  'Link Description' => 'Descripción del enlace',
  'Generate Your' => 'Genere su',
  'Re-generate Your' => 'Re-Generate Your',
  'Get Your' => 'Consiga su',
  'Your' => 'Tu',
);