<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Μην δημοσιεύετε τίποτα που παραβιάζει τους Όρους Παροχής Υπηρεσιών του Facebook. Επίσης, μην δημοσιεύετε υπερβολικά ότι θεωρείται ως ανεπιθύμητη αλληλογραφία.",
  "We recommend to use your own domain for your own branding and also for your security." => "Σας συνιστούμε να χρησιμοποιήσετε το δικό σας domain για το δικό σας branding και επίσης για την ασφάλειά σας.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Διατηρούμε το δικαίωμα να απενεργοποιήσουμε το λογαριασμό σας αν βρούμε κάτι που παραβιάζετε τους κανόνες. Εκτιμούμε τη βοήθειά σας να διατηρήσετε αυτό το σύστημα ασφαλές για όλους.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'Σας συνιστούμε να χρησιμοποιήσετε το δικό σας domain για το δικό σας branding και επίσης για την ασφάλειά σας.',
  'use your own domain for post unlimited on Facebook.' => 'χρησιμοποιήστε το δικό σας domain για post απεριόριστη στο Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'μέγιστη επιτρεπόμενη ανάρτηση Facebook ανά καμπάνια χρησιμοποιώντας τον προεπιλεγμένο ελεγκτή ενέργειας',
);