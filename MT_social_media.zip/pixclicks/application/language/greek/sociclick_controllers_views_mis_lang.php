<?php 

$lang = array (
  'Account Import Facebook' => 'Εισαγωγή λογαριασμού Facebook',
  'Clickable Image Campaign' => 'Clickable Image Campaign',
  'Clickable Image Campaign Scheduling' => 'Προγραμματισμός εκστρατείας καμπάνιας με δυνατότητα δημιουργίας αντιγράφων',
  'Clickable Image Social Post' => 'Clickable Image Social Post',
  'Custom Domain' => 'Προσαρμοσμένος τομέας',
  'Traffic Analytics' => 'Traffic Analytics',
  'Overview' => 'Επισκόπηση',
  'Country Wise Report' => 'Αναφορά χώρας',
  'Browser Report' => 'Αναφορά προγράμματος περιήγησης',
  'OS Report' => 'Έκθεση OS',
  'Device Report' => 'Αναφορά συσκευής',
  'Raw Data' => 'Ακατέργαστα δεδομένα',
  'Raw Data Report' => 'Έκθεση πρώτων δεδομένων',
  'Link Title' => 'Τίτλος συνδέσμου',
  'Link Description' => 'Περιγραφή συνδέσμου',
  'Generate Your' => 'Δημιουργήστε το δικό σας',
  'Re-generate Your' => 'Αναδημιουργήστε το δικό σας',
  'Get Your' => 'Πάρτε σας',
  'Your' => 'Το δικό σου',
);