<?php

$lang = 

array (
  'Recent Activities' => 'Πρόσφατες Δραστηριότητες',
  "Today's New Visitor Report" => "Έκθεση της Νέας Επισκέπτης σημερινή",
  'save' => 'αποθηκεύσετε',
  'generate widget code' => 'παράγουν widget κώδικα',
  'send' => 'στέλνω',
  'cancel' => 'ματαίωση',
  'close' => 'κοντά',
  'add' => 'προσθέτω',
  'edit' => 'επεξεργασία',
  'update' => 'εκσυγχρονίζω',
  'details' => 'καθέκαστα',
  'view' => 'θέα',
  'read' => 'διαβάζω',
  'delete' => 'διαγράφω',
  'search' => 'έρευνα',
  'print' => 'αποτύπωμα',
  'download' => 'κατεβάσετε',
  'keyword' => 'λέξη-κλειδί',
  'actions' => 'δράσεις',
  'search by' => 'Αναζήτηση με',
  'total' => 'σύνολο',
  'more info' => 'περισσότερες πληροφορίες',
  'status' => 'κατάσταση',
  'active' => 'ενεργός',
  'inactive' => 'αδρανής',
  'yes' => 'Ναί',
  'no' => 'όχι',
  'OR' => 'Ή',
  'only me' => 'μόνο εγώ',
  'everyone' => 'καθένας'
);