<?php 


$lang = array (
  'Account Import Facebook' => 'Account Import Facebook',
  'Clickable Image Campaign' => 'Clickable Image Campaign',
  'Clickable Image Campaign Scheduling' => 'Clickable Image Campaign Scheduling',
  'Clickable Image Social Post' => 'Clickable Image Social Post',
  'Custom Domain' => 'Custom Domain',
  'Traffic Analytics' => 'Traffic Analytics',
  'Overview' => 'Overview',
  'Country Wise Report' => 'Country Wise Report',
  'Browser Report' => 'Browser Report',
  'OS Report' => 'OS Report',
  'Device Report' => 'Device Report',
  'Raw Data' => 'Raw Data',
  'Raw Data Report' => 'Raw Data Report',
  'Link Title' => 'Link Title',
  'Link Description' => 'Link Description',
  'Generate Your' => 'Generate Your',
  'Re-generate Your' => 'Re-Generate Your',
  'Get Your' => 'Get Your',
  'Your' => 'Your',
);