<?php

$lang = 

array (
  'Recent Activities' => 'Recent Activities',
  "Today's New Visitor Report" => "Today's New Visitor Report",
  'save' => 'Save',
  'generate widget code' => 'Generate Widget Code',
  'send' => 'Send',
  'cancel' => 'Cancel',
  'close' => 'Close',
  'add' => 'Add',
  'edit' => 'Edit',
  'update' => 'Update',
  'details' => 'Details',
  'view' => 'View',
  'read' => 'Read',
  'delete' => 'Delete',
  'search' => 'Search',
  'print' => 'Print',
  'download' => 'Download',
  'keyword' => 'Keyword',
  'actions' => 'Actions',
  'search by' => 'Search By',
  'total' => 'Total',
  'more info' => 'Details',
  'status' => 'Status',
  'active' => 'Active',
  'inactive' => 'Inactive',
  'yes' => 'Yes',
  'no' => 'No',
  'OR' => 'OR',
  'only me' => 'Only Me',
  'everyone' => 'Everyone'
);