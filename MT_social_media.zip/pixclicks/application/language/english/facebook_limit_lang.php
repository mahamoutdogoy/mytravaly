<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Please do not post anything that violates Facebook Terms of Service. Also do not post too much that it is considered as spam.",
  "We recommend to use your own domain for your own branding and also for your security." => "We recommend to use your own domain for your own branding and also for your security.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'We recommend to use your own domain for your own branding and also for your security.',
  'use your own domain for post unlimited on Facebook.' => 'use your own domain for post unlimited on Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'maximum allowed Facebook post per campaign using default action controller:',
);