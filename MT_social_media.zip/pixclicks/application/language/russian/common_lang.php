<?php
$lang['Recent Activities'] = "Последние действия";
$lang["Today's New Visitor Report"] = "Сегодня Новый посетитель отчет";
// admin sidebar
$lang["save"] 			    = "спасти";
$lang["generate widget code"] 	= "генерировать код виджета";
$lang["send"] 			    = "Отправить";
$lang["cancel"] 			= "Отмена";
$lang["close"] 				= "Закрыть";
$lang["add"] 				= "Добавить";
$lang["edit"] 				= "редактировать";
$lang["update"] 			= "Обновить";
$lang["details"] 			= "Детали";
$lang["view"] 			    = "Посмотреть";
$lang["read"] 			    = "читать";
$lang["delete"] 			= "Удалить";
$lang["search"] 			= "поиск";
$lang["print"] 				= "Распечатать";
$lang["download"] 			= "скачать";
$lang["keyword"] 			= "ключевое слово";
$lang["actions"] 			= "действия";
$lang["search by"] 			= "искать по";
$lang["total"] 			    = "Всего";
$lang["more info"] 			= "больше информации";

$lang["status"] 			= "положение дел";
$lang["active"] 			= "активный";
$lang["inactive"] 			= "неактивный";
$lang["yes"] 				= "да";
$lang["no"] 				= "нет";
$lang["OR"] 				= "ИЛИ";
$lang["only me"] 			= "только я";
$lang["everyone"] 			= "все";
