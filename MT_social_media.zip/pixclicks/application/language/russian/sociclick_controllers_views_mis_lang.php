<?php 


$lang = array (
  'Account Import Facebook' => 'Импорт аккаунта',
  'Clickable Image Campaign' => 'Кампания с кликами',
  'Clickable Image Campaign Scheduling' => 'Планирование кампаний с плавающей запятой',
  'Clickable Image Social Post' => 'Отправить по электронной почте',
  'Custom Domain' => 'Пользовательский домен',
  'Traffic Analytics' => 'Аналитика трафика',
  'Overview' => 'обзор',
  'Country Wise Report' => 'Страновой отчет',
  'Browser Report' => 'Отчет о браузере',
  'OS Report' => 'Отчет о ОС',
  'Device Report' => 'Отчет об устройстве',
  'Raw Data' => 'Сырые данные',
  'Raw Data Report' => 'Отчет о необработанных данных',
  'Link Title' => 'Название ссылки',
  'Link Description' => 'Ссылка Описание',
  'Generate Your' => 'Создайте свой',
  'Re-generate Your' => 'Восстановите свой',
  'Get Your' => 'Получите ваш',
  'Your' => 'ваш',
);