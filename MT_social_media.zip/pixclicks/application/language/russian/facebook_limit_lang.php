<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Пожалуйста, не публикуйте ничего, что нарушает Условия использования Facebook. Также не публикуйте слишком много, чтобы это считалось спамом.",
  "We recommend to use your own domain for your own branding and also for your security." => "Мы рекомендуем использовать ваш собственный домен для собственного брендинга, а также для вашей безопасности.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Мы оставляем за собой право отключить вашу учетную запись, если найдем что-либо, что нарушаете правила. Мы ценим вашу помощь в обеспечении безопасности этой системы для всех.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'Мы рекомендуем использовать ваш собственный домен для собственного брендинга, а также для вашей безопасности.',
  'use your own domain for post unlimited on Facebook.' => 'используйте свой собственный домен для неограниченного доступа на Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'максимально допустимое сообщение Facebook за кампанию с использованием контроллера действий по умолчанию:',
);