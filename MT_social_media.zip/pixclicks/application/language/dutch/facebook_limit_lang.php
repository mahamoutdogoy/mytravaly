<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Plaats alsjeblieft niets dat in strijd is met de gebruiksvoorwaarden van Facebook. Voer ook niet te veel in dat het als spam wordt beschouwd.",
  "We recommend to use your own domain for your own branding and also for your security." => "We raden u aan om uw eigen domein te gebruiken voor uw eigen branding en ook voor uw veiligheid.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Wij behouden ons het recht voor uw account uit te schakelen als we iets vinden dat u de regels overtreden. Wij waarderen uw hulp om dit systeem veilig te houden voor iedereen.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'We raden u aan om uw eigen domein te gebruiken voor uw eigen branding en ook voor uw veiligheid.',
  'use your own domain for post unlimited on Facebook.' => 'Gebruik je eigen domein voor onbeperkt bericht op Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'Maximaal toegestaan Facebook-bericht per campagne met behulp van de standaardactiecontroller:',
);