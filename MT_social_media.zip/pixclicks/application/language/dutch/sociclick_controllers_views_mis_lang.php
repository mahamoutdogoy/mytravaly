<?php 


$lang = array (
  'Account Import Facebook' => 'Account importeren Facebook',
  'Clickable Image Campaign' => 'Klikbare beeldcampagne',
  'Clickable Image Campaign Scheduling' => 'Clickable Image Campaign Scheduling',
  'Clickable Image Social Post' => 'Klikbare Image Social Post',
  'Custom Domain' => 'Aangepast domein',
  'Traffic Analytics' => 'Traffic Analytics',
  'Overview' => 'Overzicht',
  'Country Wise Report' => 'Country Wise Report',
  'Browser Report' => 'Browserrapport',
  'OS Report' => 'OS rapport',
  'Device Report' => 'Apparaatrapport',
  'Raw Data' => 'Ruwe data',
  'Raw Data Report' => 'Raw Data Report',
  'Link Title' => 'Link Titel',
  'Link Description' => 'Link beschrijving',
  'Generate Your' => 'Genereer uw',
  'Re-generate Your' => 'Genereer uw',
  'Get Your' => 'Krijg je',
  'Your' => 'Jouw',
);