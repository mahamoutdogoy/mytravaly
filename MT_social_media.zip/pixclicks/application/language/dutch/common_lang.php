<?php
$lang['Recent Activities'] = "recente activiteiten";
$lang["Today's New Visitor Report"] = "Today's New Visitor Report";
// admin sidebar
$lang["save"] 			    = "besparen";
$lang["generate widget code"] 	= "genereren widget code";
$lang["send"] 			    = "sturen";
$lang["cancel"] 			= "Annuleer";
$lang["close"] 				= "dichtbij";
$lang["add"] 				= "toevoegen";
$lang["edit"] 				= "edit";
$lang["update"] 			= "bijwerken";
$lang["details"] 			= "gegevens";
$lang["view"] 			    = "uitzicht";
$lang["read"] 			    = "lezen";
$lang["delete"] 			= "verwijderen";
$lang["search"] 			= "zoeken";
$lang["print"] 				= "afdrukken";
$lang["download"] 			= "downloaden";
$lang["keyword"] 			= "trefwoord";
$lang["actions"] 			= "acties";
$lang["search by"] 			= "zoek met";
$lang["total"] 			    = "totaal";
$lang["more info"] 			= "meer informatie";

$lang["status"] 			= "toestand";
$lang["active"] 			= "actief";
$lang["inactive"] 			= "inactief";
$lang["yes"] 				= "Ja";
$lang["no"] 				= "Nee";
$lang["OR"] 				= "OF";
$lang["only me"] 			= "alleen ik";
$lang["everyone"] 			= "iedereen";
