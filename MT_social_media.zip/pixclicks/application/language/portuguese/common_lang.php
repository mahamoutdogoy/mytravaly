<?php
$lang['Recent Activities'] = "Atividades recentes";
$lang["Today's New Visitor Report"] = "Relatório Novo visitante de hoje";
// admin sidebar
$lang["save"] 			    = "salvar";
$lang["generate widget code"] 	= "gerar código do widget";
$lang["send"] 			    = "enviar";
$lang["cancel"] 			= "cancelar";
$lang["close"] 				= "fechar";
$lang["add"] 				= "adicionar";
$lang["edit"] 				= "editar";
$lang["update"] 			= "atualizar";
$lang["details"] 			= "detalhes";
$lang["view"] 			    = "Visão";
$lang["read"] 			    = "ler";
$lang["delete"] 			= "excluir";
$lang["search"] 			= "excluir";
$lang["print"] 				= "impressão";
$lang["download"] 			= "baixar";
$lang["keyword"] 			= "palavra chave";
$lang["actions"] 			= "ações";
$lang["search by"] 			= "procurar por";
$lang["total"] 			    = "total";
$lang["more info"] 			= "mais informações";

$lang["status"] 			= "estado";
$lang["active"] 			= "ativo";
$lang["inactive"] 			= "inativo";
$lang["yes"] 				= "sim";
$lang["no"] 				= "não";
$lang["OR"] 				= "OU";
$lang["only me"] 			= "só eu";
$lang["everyone"] 			= "todos";
