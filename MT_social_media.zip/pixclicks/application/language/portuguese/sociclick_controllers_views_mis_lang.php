<?php 


$lang = array (
  'Account Import Facebook' => 'Conta Importar Facebook',
  'Clickable Image Campaign' => 'Campanha de Imagem Clickable',
  'Clickable Image Campaign Scheduling' => 'Agendamento da campanha da imagem clicável',
  'Clickable Image Social Post' => 'Imagem Clickable Social Post',
  'Custom Domain' => 'Domínio personalizado',
  'Traffic Analytics' => 'Traffic Analytics',
  'Overview' => 'Visão geral',
  'Country Wise Report' => 'Country Wise Report',
  'Browser Report' => 'Relatório do navegador',
  'OS Report' => 'Relatório do SO',
  'Device Report' => 'Relatório do dispositivo',
  'Raw Data' => 'Dados brutos',
  'Raw Data Report' => 'Relatório de dados brutos',
  'Link Title' => 'Título do link',
  'Link Description' => 'Descrição do link',
  'Generate Your' => 'Gerar seu',
  'Re-generate Your' => 'Re-Generar seu',
  'Get Your' => 'Obter seu',
  'Your' => 'Seu',
);