<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Não publique nada que viole os Termos de Serviço do Facebook. Além disso, não publique muito que é considerado spam.",
  "We recommend to use your own domain for your own branding and also for your security." => "Recomendamos usar seu próprio domínio para sua própria marca e também para sua segurança.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Reservamo-nos o direito de desativar sua conta se acharmos qualquer coisa que esteja violando as regras. Agradecemos sua ajuda para manter este sistema seguro para todos.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'Recomendamos usar seu próprio domínio para sua própria marca e também para sua segurança.',
  'use your own domain for post unlimited on Facebook.' => 'use seu próprio domínio para publicação ilimitada no Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'Postagem máxima permitida do Facebook por campanha usando o controlador de ação padrão:',
);