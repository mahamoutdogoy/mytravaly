<?php 

$lang = array (
  'Account Import Facebook' => 'Tài khoản nhập Facebook',
  'Clickable Image Campaign' => 'Chiến dịch Hình ảnh Nhấp',
  'Clickable Image Campaign Scheduling' => 'Lập biểu Chiến dịch Hình ảnh Nhấp Hình',
  'Clickable Image Social Post' => 'Bài đăng xã hội trên Clickable Image',
  'Custom Domain' => 'Tên miền tùy chỉnh',
  'Traffic Analytics' => 'Analytics lưu lượng truy cập',
  'Overview' => 'Tổng quan',
  'Country Wise Report' => 'Báo cáo khôn ngoan của quốc gia',
  'Browser Report' => 'Báo cáo trình duyệt',
  'OS Report' => 'Báo cáo Hệ điều hành',
  'Device Report' => 'Báo cáo thiết bị',
  'Raw Data' => 'Dữ liệu thô',
  'Raw Data Report' => 'Báo cáo dữ liệu thô',
  'Link Title' => 'Tiêu đề liên kết',
  'Link Description' => 'Mô tả liên kết',
  'Generate Your' => 'Tạo ra',
  'Re-generate Your' => 'Re-Tạo của bạn',
  'Get Your' => 'Nhận được của bạn',
  'Your' => 'Bạn',
);