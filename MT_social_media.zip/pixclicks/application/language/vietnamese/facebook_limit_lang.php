<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Vui lòng không đăng bất kỳ nội dung nào vi phạm Điều khoản Dịch vụ của Facebook. Cũng không đăng quá nhiều mà nó được coi là thư rác.",
  "We recommend to use your own domain for your own branding and also for your security." => "Chúng tôi khuyên bạn nên sử dụng tên miền riêng của bạn cho việc xây dựng thương hiệu của chính bạn cũng như bảo mật của bạn.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Chúng tôi bảo lưu quyền vô hiệu hóa tài khoản của bạn nếu chúng tôi tìm thấy bất cứ điều gì bạn vi phạm các quy tắc. Chúng tôi đánh giá cao sự giúp đỡ của bạn để giữ cho hệ thống này an toàn cho mọi người.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'Chúng tôi khuyên bạn nên sử dụng tên miền riêng của bạn cho việc xây dựng thương hiệu của chính bạn cũng như bảo mật của bạn.',
  'use your own domain for post unlimited on Facebook.' => 'sử dụng tên miền riêng của bạn để đăng bài không giới hạn trên Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'bài đăng trên Facebook cho mỗi chiến dịch sử dụng bộ điều khiển hành động mặc định:',
);