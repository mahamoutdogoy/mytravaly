<?php

$lang = 

array (
  'Recent Activities' => 'Hoạt động gần đây',
  "Today's New Visitor Report" => "Báo cáo mới của khách ngày nay",
  'save' => 'Tiết kiệm',
  'generate widget code' => 'Tạo Widget Mã',
  'send' => 'gởi',
  'cancel' => 'hủy bỏ',
  'close' => 'Gần',
  'add' => 'Thêm vào',
  'edit' => 'Chỉnh sửa',
  'update' => 'cập nhật',
  'details' => 'Thông tin chi tiết',
  'view' => 'Lượt xem',
  'read' => 'Đọc',
  'delete' => 'Xóa bỏ',

  'search' => 'Tìm kiếm',
  'print' => 'In',
  'download' => 'Tải về',
  'keyword' => 'Từ khóa',
  'actions' => 'Hoạt động',
  'search by' => 'Tìm kiếm bởi',
  'total' => 'Tổng số',
  'more info' => 'Thông tin chi tiết',
  'status' => 'Trạng thái',
  'active' => 'hoạt động',
  'inactive' => 'Không hoạt động',
  'yes' => 'Vâng',
  'no' => 'Không',
  'OR' => 'HOẶC LÀ',

  'only me' => 'Chỉ có tôi',
  'everyone' => 'Tất cả mọi người'

);