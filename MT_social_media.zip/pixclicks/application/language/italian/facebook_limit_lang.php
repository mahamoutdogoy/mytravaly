<?php

$lang = array (
  "Please don't post anything that violates Facebook Terms of Service. Also don't post too much that it's considered as spam." => "Non invii messaggi che violano i Termini di servizio di Facebook. Inoltre non inviare troppo che sia considerato come spam.",
  "We recommend to use your own domain for your own branding and also for your security." => "Si consiglia di utilizzare il proprio dominio per il proprio marchio e anche per la tua sicurezza.",
  'We reserve the right to disable your account if we find anything that you are violating the rules. We appreciate your help to keep this system safe for everyone.' => 'Ci riserviamo il diritto di disattivare il tuo account se troviamo qualcosa che stai violando le regole. Apprezziamo il tuo aiuto per mantenere questo sistema sicuro per tutti.',
  'We recommend to use your own domain for your own branding and also for your security.' => 'Si consiglia di utilizzare il proprio dominio per il proprio marchio e anche per la tua sicurezza.',
  'use your own domain for post unlimited on Facebook.' => 'utilizzare il tuo dominio per il post illimitato su Facebook.',
  'maximum allowed Facebook post per campaign using default action controller:' => 'post di Facebook massimo consentito per campagna che utilizza il controller di azioni predefinito:',
);