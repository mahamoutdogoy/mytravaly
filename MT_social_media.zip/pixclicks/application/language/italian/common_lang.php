<?php
$lang['Recent Activities'] = "Attività recenti";
$lang["Today's New Visitor Report"] = "Relazione Nuovo visitatore di oggi";
// admin sidebar
$lang["save"] 			    = "salvare";
$lang["generate widget code"] 	= "generare codice del widget";
$lang["send"] 			    = "inviare";
$lang["cancel"] 			= "Annulla";
$lang["close"] 				= "vicino";
$lang["add"] 				= "aggiungere";
$lang["edit"] 				= "Modifica";
$lang["update"] 			= "aggiornare";
$lang["details"] 			= "dettagli";
$lang["view"] 			    = "vista";
$lang["read"] 			    = "leggi";
$lang["delete"] 			= "cancellare";
$lang["search"] 			= "ricerca";
$lang["print"] 				= "stampare";
$lang["download"] 			= "Scaricare";
$lang["keyword"] 			= "parola chiave";
$lang["actions"] 			= "azioni";
$lang["search by"] 			= "cercato da";
$lang["total"] 			    = "totale";
$lang["more info"] 			= "Ulteriori informazioni";

$lang["status"] 			= "stato";
$lang["active"] 			= "attivo";
$lang["inactive"] 			= "inattivo";
$lang["yes"] 				= "sì";
$lang["no"] 				= "no";
$lang["OR"] 				= "O";
$lang["only me"] 			= "solo io";
$lang["everyone"] 			= "tutti";

