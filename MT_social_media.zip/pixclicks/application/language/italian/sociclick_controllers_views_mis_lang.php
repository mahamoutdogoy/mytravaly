<?php 

$lang = array (
  'Account Import Facebook' => 'Account Importa Facebook',
  'Clickable Image Campaign' => 'Campagna di immagine cliccabile',
  'Clickable Image Campaign Scheduling' => 'Programmazione delle campagne di immagine cliccabili',
  'Clickable Image Social Post' => 'Immagine sociale immagine cliccabile',
  'Custom Domain' => 'Domain personalizzato',
  'Traffic Analytics' => 'Analisi del traffico',
  'Overview' => 'panoramica',
  'Country Wise Report' => 'Rapporto Country Wise',
  'Browser Report' => 'Rapporto del browser',
  'OS Report' => 'Rapporto OS',
  'Device Report' => 'Report sul dispositivo',
  'Raw Data' => 'Dati crudi',
  'Raw Data Report' => 'Rapporto di dati raw',
  'Link Title' => 'Titolo del collegamento',
  'Link Description' => 'Descrizione del collegamento',
  'Generate Your' => 'Genera il tuo',
  'Re-generate Your' => 'Ri-generare il tuo',
  'Get Your' => 'Prendi il tuo',
  'Your' => 'la tua',
);