<?php 
$config['default_page_url'] = 'page/blank';
$config['product_name'] = 'PixClicks';
$config['product_short_name'] = 'PixClicks';
$config['product_version'] = '1.3';
$config['institute_address1'] = '';
$config['institute_address2'] = '';
$config['institute_email'] = '';
$config['institute_mobile'] = '';

$config['developed_by'] = '';
$config['developed_by_href'] = '';
$config['developed_by_title'] = '';
$config['developed_by_prefix'] = '' ;
$config['support_email'] = '' ;
$config['support_mobile'] = '' ;
$config['time_zone'] = '';
$config['language'] = 'english';
$config['sess_use_database'] = FALSE;
$config['sess_table_name'] = 'ci_sessions';
$config['theme'] = 'skin-blue-light';
$config['display_landing_page'] = 0;
$config['check_post_count_limit'] = 0;
$config['use_app_domain_as_action_controller_link'] = FALSE;
