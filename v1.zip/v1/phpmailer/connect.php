<?php
$con=mysqli_connect("localhost","root","","mytravaly") or die(mysqli_connect_error());

?>