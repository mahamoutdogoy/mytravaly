

<head>

<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">


 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
<style type="text/css">
	.row {
		text-align: justify;
	}
	img[src="http://localhost/mytravaly/images/logo.png"] {
	padding-top:-20px;
	height:75px;
		
	}
	img[src="http://localhost/mytravaly/images/logo.png"]:hover
	ul.nav li {
		padding-top:8px;
	}
	ul.nav li a {
		color: #FF6F61;
		padding: 5px;
		margin-right: 8px;
	}
	.hotels a:hover,ul.nav li a:hover {
		padding: 5px;
		background-color:#20b2aa;
		border-radius: 5px;
		color: black;
		line-height:20px;
	} 

	.hotels {
		
		padding: 0px;

	}
	.top_container {
	margin-top:20px;
	}
	#top_menu {
		position: absolute;
		left: 873px;
		background-color:#FF6F61;

		border-radius: 5px;

	}



	
	

	#top_menu ul li a {
	color: white;
	padding: 2px;
	padding-top: 1px;
	margin-top: -5px;
	border-right: 0px solid white;
	}

	#top_menu ul li a:hover {
		background-color:#FF6F56;
	}

    a > .ico {
    background-color: grey;
    padding: 10px;
    padding-top: 20px;
    
}
a:hover > .ico {
    background-color: #666;
}

    
</style>
</head>
<!--top menu-->
<div class="container mb-3" onload="ccount();">
	<div>
		<div>
			<a href=""><img src="http://localhost/mytravaly/images/logo.png" class="float-left" alt="" style="margin-left:-90px; "></a>
		    <div id="top_menu">
				<ul class="nav list-unstyled float-right">
					<li class="nav-item"><a class="nav-link" href="#"><span><i class="fa fa-globe-asia"></i></span>&nbsp;Language</a></li>
					<li><a href="#" class="nav-link"><span><i class="fa fa-money-bill-alt"></i></span>&nbsp;Currency</a></li>
					<li><a href="#" class="nav-link"><span><i class="fa fa-plus"></i></span>&nbsp;Add your property</a></li>
					<li><a href="#exampleModal" data-toggle="modal" data-target="#exampleModal" class="nav-link"><span><i class="fa fa-sign-in"></i></span>&nbsp;Login</a></li>
				</ul>
			</div>
			
		</div>
		<br>
		<br>
		
		
	</div>
</div>
<!--top menu-->

<head>
<script type="text/javascript" src="js/jquery-3.3.1.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.4/js/tether.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/radialIndicator/1.3.1/radialIndicator.js"></script>  
</head>