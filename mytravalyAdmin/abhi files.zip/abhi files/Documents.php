<?php include 'propertymenus.php';?>
<div>
	<br>
	<br>

<table align="center" width="750px" cellpadding="5" class="table-striped" cellspacing="10" style="opacity: 0.8;">
	<tr style="background:#ff6f61;font-size: 20px;">
		<td colspan="2" align="center" style="padding-top:.9em;padding-bottom:.9em;"><b>Documents</b></td>
	</tr>
	<tr><td align="center">Incorporation Certificats/Trade </td>
		<td style="padding-top:.9em;padding-bottom:.9em;"><input type="File" name=""></td>
	</tr>
	<tr>
		<td align="center">Tax/GST Certificate</td>
		<td style="padding-top:.9em;padding-bottom:.9em;"><input type="file" name=""></td>

	</tr>

	<tr>
		<td align="center">Pan/Tax Identification No</td>
		<td style="padding-top:.9em;padding-bottom:.9em;"><input type="file" name=""></td>
	</tr>
	<tr>
		<td align="center">Cancel Cheque</td>
		<td style="padding-top:.9em;padding-bottom:.9em;"><input type="file" name=""></td>
	</tr>
	
	<table>
</div>