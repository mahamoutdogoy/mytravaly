<?php include 'propertymenus.php';?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div>
	<table align="center" width="1000px" cellpadding="5" class="table-striped" cellspacing="5" style="opacity: 0.8;">
			
			<tr style="background:#ff6f61;font-size: 20px;">
				<th style="opacity: 0.8;padding-top: .7em;padding-bottom: .7em;">Featurers</th>
				<th>Select</th>
				<th>Featurers</th>
				<th>Select</th>
				<th>Featurers</th>
				<th>Select</th>
			</tr>
			<tr>
				<td>Baby sitting</td>
				<td><input type="checkbox" name=""></td>
				<td>Beauty salon</td>
				<td><input type="checkbox" name=""></td>
				<td>24-Hour Security</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Bay View</td>
				<td><input type="checkbox" name=""></td>
				<td>Body Treatments</td>
				<td><input type="checkbox" name=""></td>
				<td>Boutique</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Bus Parking</td>
				<td><input type="checkbox" name=""></td>
				<td>Catering Services</td>
				<td><input type="checkbox" name=""></td>
				<td>Laundry/Valet Services</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Complimentary Breakfast</td>
				<td><input type="checkbox" name=""></td>
				<td>Free Parking</td>
				<td><input type="checkbox" name=""></td>
				<td>Business services</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Adjoining Room</td>
				<td><input type="checkbox" name=""></td>
				<td>Outdoor Swimming Pool</td>
				<td><input type="checkbox" name=""></td>
				<td>LCD/Projector</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Interconnecting Rooms</td>
				<td><input type="checkbox" name=""></td>
				<td>Phone Service</td>
				<td><input type="checkbox" name=""></td>
				<td>Color television</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Housekeeping- Daily</td>
				<td><input type="checkbox" name=""></td>
				<td>24-hour front desk</td>
				<td><input type="checkbox" name=""></td>
				<td>Hair dryer</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			
			<tr>
				<td>Express Check Out</td>
				<td><input type="checkbox" name=""></td>
				<td>24-hour room service</td>
				<td><input type="checkbox" name=""></td>
				<td>Internet access</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Female Traveler Room</td>
				<td><input type="checkbox" name=""></td>
				<td>Air conditioning</td>
				<td><input type="checkbox" name=""></td>
				<td>Balcony</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			
			<tr>
				<td>Free Newspaper</td>
				<td><input type="checkbox" name=""></td>
				<td>ATM/Cash machine</td>
				<td><input type="checkbox" name=""></td>
				<td>Bath Tub</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Bathrobe</td>
				<td><input type="checkbox" name=""></td>
				<td>Bedside lamp</td>
				<td><input type="checkbox" name=""></td>
				<td>Direct Dialing</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Direct Dialing</td>
				<td><input type="checkbox" name=""></td>
				<td>DVD Player</td>
				<td><input type="checkbox" name=""></td>
				<td>Disabled Features</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Express Laundry Service</td>
				<td><input type="checkbox" name=""></td>
				<td>Laundry Bag</td>
				<td><input type="checkbox" name=""></td>
				<td>Luggage space</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Marble flooring</td>
				<td><input type="checkbox" name=""></td>
				<td>Parallel phone line in bathroom</td>
				<td><input type="checkbox" name=""></td>
				<td>Writing Desk</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Satellite TV</td>
				<td><input type="checkbox" name=""></td>
				<td>Table lamp</td>
				<td><input type="checkbox" name=""></td>
				<td>Complimentary Wi-Fi access</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Pool Snack Bar</td>
				<td><input type="checkbox" name=""></td>
				<td>Porters</td>
				<td><input type="checkbox" name=""></td>
				<td>Internet</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Gym</td>
				<td><input type="checkbox" name=""></td>
				<td>Pool</td>
				<td><input type="checkbox" name=""></td>
				<td>Free Transportation</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Heated Pool</td>
				<td><input type="checkbox" name=""></td>
				<td>Sauna</td>
				<td><input type="checkbox" name=""></td>
				<td>Shopping Arcade</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Steam Bath</td>
				<td><input type="checkbox" name=""></td>
				<td>Vending Machines</td>
				<td><input type="checkbox" name=""></td>
				<td>Video Game Player</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<tr>
				<td>Indoor Game</td>
				<td><input type="checkbox" name=""></td>
				<td>Conference facilities</td>
				<td><input type="checkbox" name=""></td>
				<td>Disco</td>
				<td><input type="checkbox" name=""></td>
			</tr>
			<br>
			<br>
			<tr><td></td></tr>
			<tr>
				<td colspan="6" align="center">
					<input type="submit" name="save" value="Save" class="btn btn-success" style="border-radius: 2.0em;width:150px"></td>
			</tr>
	</table>
</div>
</body>
</html>